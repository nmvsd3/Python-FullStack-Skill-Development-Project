from django.apps import AppConfig


class CargoAppConfig(AppConfig):
    name = 'cargo_app'
